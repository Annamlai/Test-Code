function Petworld(evt, petName) {
  var i, tabcontent, petlinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  petlinks = document.getElementsByClassName("petlinks");
  for (i = 0; i < petlinks.length; i++) {
    petlinks[i].className = petlinks[i].className.replace(" active", "");
  }
  document.getElementById(petName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click(); 